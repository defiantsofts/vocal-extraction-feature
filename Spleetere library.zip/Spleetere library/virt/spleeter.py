import tkinter as tk
import os
from tkinter import filedialog, messagebox
from spleeter.separator import Separator

class VocalExtractionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Vocal Extraction App")
        
        self.upload_button = tk.Button(root, text="Upload WAV File", command=self.upload_wav)
        self.upload_button.pack(pady=10)
        
        self.extract_button = tk.Button(root, text="Extract Vocals", command=self.extract_vocals, state=tk.DISABLED)
        self.extract_button.pack(pady=5)
        
        self.save_button = tk.Button(root, text="Save Extracted Vocals", command=self.save_extracted_vocals, state=tk.DISABLED)
        self.save_button.pack(pady=5)
        
        self.separator = Separator('spleeter:2stems')  # Initialize Spleeter
        
    def upload_wav(self):
        self.wav_file_path = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")])
        if self.wav_file_path:
            self.extract_button.config(state=tk.NORMAL)
            
    def extract_vocals(self):
        # Use Spleeter for vocal extraction
        output_dir = 'output'  # Output directory where separated tracks will be saved
        os.makedirs(output_dir, exist_ok=True)
        self.separator.separate_to_file(self.wav_file_path, output_dir)
        
        self.save_button.config(state=tk.NORMAL)
        self.show_message("Vocals extracted successfully!")
        
    def save_extracted_vocals(self):
        extracted_file_path = filedialog.asksaveasfilename(defaultextension=".mp3", filetypes=[("MP3 files", "*.mp3")])
        if extracted_file_path:
            # Convert WAV to MP3 using appropriate libraries (not shown in this code)
            self.show_message("Extracted vocals saved successfully!")
        
    def show_message(self, message):
        messagebox.showinfo("Message", message)

root = tk.Tk()
app = VocalExtractionApp(root)
root.mainloop()